#ifndef H_samHeaders
#define H_samHeaders

#include "Parameters.h"
#include "Genome.h"
#include "Transcriptome.h"

void samHeaders(Parameters &P, Genome &genomeMain, Transcriptome &transcriptomeMain);

#endif