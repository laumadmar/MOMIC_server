#ifndef H_AlignVsTranscript
#define H_AlignVsTranscript

namespace AlignVsTranscript 
{
    enum {Intron=0, ExonIntron=1, ExonIntronSpan=2, Concordant=3, N=4};
};

#endif