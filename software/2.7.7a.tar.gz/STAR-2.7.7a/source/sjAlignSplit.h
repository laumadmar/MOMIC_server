#ifndef H_sjAlignSplit
#define H_sjAlignSplit

#include "IncludeDefine.h"
#include "Genome.h"

bool sjAlignSplit(uint a1,uint aLength, const Genome &mapGen, uint &a1D, uint &aLengthD, uint &a1A, uint &aLengthA, uint &isj);

#endif
